# SMTPariedAssignmentG18

This project aimed to build a Telegram Bot that can easily provide users with a list of bus arrival time when the user gives a specific bus stop number. 

Please copy the offset.txt file into root file (the same place as your ay18t2-smt203-asm-01.py file).
Please copy the offset.txt file into root file (the same place as your ay18t2-smt203-asm-01.py file).
Please copy the offset.txt file into root file (the same place as your ay18t2-smt203-asm-01.py file).
Please copy the offset.txt file into root file (the same place as your ay18t2-smt203-asm-01.py file).
Please copy the offset.txt file into root file (the same place as your ay18t2-smt203-asm-01.py file).
